from tkinter import *
from time import *
from PIL import ImageTk, Image

# creating tkinter window
root = Tk()
root.geometry('400x180')
root.title('Organ Clock')

organ_list = ['gall bladder.png', 'liver.png', 'lungs.png', 'large intestine.png', 'stomach.png', 'spleen.png', 'heart.png', 'small intestine.png', 'bladder.png', 'kidneys.png', 'pericardium.png', 'triple warmer.png']

width = 50
height = 50
img1 = Image.open("gall bladder.png")
img1 = img1.resize((width, height), Image.ANTIALIAS)
gall_bladder_img = ImageTk.PhotoImage(img1)

img2 = Image.open("liver.png")
img2 = img2.resize((width, height), Image.ANTIALIAS)
liver_img = ImageTk.PhotoImage(img2)

img3 = Image.open("lungs.png")
img3 = img3.resize((width, height), Image.ANTIALIAS)
lungs_img = ImageTk.PhotoImage(img3)

img4 = Image.open("large intestine.png")
img4 = img4.resize((width, height), Image.ANTIALIAS)
large_intestine_img = ImageTk.PhotoImage(img4)

img5 = Image.open("stomach.png")
img5 = img5.resize((width, height), Image.ANTIALIAS)
stomach_img = ImageTk.PhotoImage(img5)

img6 = Image.open("spleen.png")
img6 = img6.resize((width, height), Image.ANTIALIAS)
spleen_img = ImageTk.PhotoImage(img6)

img7 = Image.open("heart.png")
img7 = img7.resize((width, height), Image.ANTIALIAS)
heart_img = ImageTk.PhotoImage(img7)

img8 = Image.open("small intestine.png")
img8 = img8.resize((width, height), Image.ANTIALIAS)
small_intestine_img = ImageTk.PhotoImage(img8)

img9 = Image.open("bladder.png")
img9 = img9.resize((width, height), Image.ANTIALIAS)
bladder_img = ImageTk.PhotoImage(img9)

img10 = Image.open("kidney.png")
img10 = img10.resize((width, height), Image.ANTIALIAS)
kidney_img = ImageTk.PhotoImage(img10)

img11 = Image.open("pericardium.png")
img11 = img11.resize((width, height), Image.ANTIALIAS)
pericardium_img = ImageTk.PhotoImage(img11)

img12 = Image.open("triple warmer.png")
img12 = img12.resize((width, height), Image.ANTIALIAS)
triple_warmer_img = ImageTk.PhotoImage(img12)

def time():
    string = strftime('%I:%M:%S %p')
    lbl.config(text=string)
    lbl.after(1000, time)
    if string[9] == 'A':
        if string[0:2] == '01' or string[0:2] == '02':
            res = 'Liver'
            lbl3.config(image=liver_img)

        elif string[0:2] == '03' or string[0:2] == '04':
            res = 'Lungs'
            lbl3.config(image=lungs_img)

        elif string[0:2] == '05' or string[0:2] == '06':
            res = 'Large Intestine'
            lbl3.config(image=large_intestine_img)

        elif string[0:2] == '07' or string[0:2] == '08':
            res = 'Stomach'
            lbl3.config(image=stomach_img)

        elif string[0:2] == '09' or string[0:2] == '10':
            res = 'Spleen'
            lbl3.config(image=spleen_img)

        elif string[0:2] == '11':
            res = 'Heart'
            lbl3.config(image=heart_img)

        elif string[0:2] == '12':
            res = 'Gall Bladder'
            lbl3.config(image=gall_bladder_img)
        else:
            res = 'something went wrong in AM'

        lbl2.config(text=res + ' at work.')

    elif string[9] == 'P':
        if string[0:2] == '01' or string[0:2] == '02':
            res = 'Small Intestine'
            lbl3.config(image=small_intestine_img)

        elif string[0:2] == '03' or string[0:2] == '04':
            res = 'Bladder'
            #lbl3.config(image=bladder_img)

        elif string[0:2] == '05' or string[0:2] == '06':
            res = 'Kidneys'
            lbl3.config(image=kidney_img)

        elif string[0:2] == '07' or string[0:2] == '08':
            res = 'Pericardium'
            #lbl3.config(image=pericardium_img)

        elif string[0:2] == '09' or string[0:2] == '10':
            res = 'Triple Warmer'
            #lbl3.config(image=triple_warmer_img)

        elif string[0:2] == '11':
            res = 'Gall Bladder'
            lbl3.config(image=gall_bladder_img)

        elif string[0:2] == '12':
            res = 'Heart'
            lbl3.config(image=heart_img)
        else:
            res = 'something went wrong in PM'
        lbl2.config(text=res + ' at work.')


lbl = Label(root, font=('calibri', 40, 'bold'),
            background='#263238',
            foreground='white')

lbl2 = Label(root, font=('calibri', 20, 'bold'),
             background='#FFD54F',
             foreground='#00695C')

lbl3 = Label(root, padx=5, pady=5)
lbl.pack(anchor='center')
lbl2.pack(anchor='center')
lbl3.pack(anchor='center')
time()

mainloop()
